package com.liuqi.mi.common.phoneVerCode;

public class test {
    public static void main(String[] args) {
        SendMessage sendMessage=new SendMessage();
        sendMessage.EX("17679164807","666666");
    }
}
